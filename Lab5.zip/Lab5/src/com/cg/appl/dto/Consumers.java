package com.cg.appl.dto;

public class Consumers {

	private int consumerNum;
	private String consumerName;
	private String consumerAddr;

	public Consumers() {

	}

	public Consumers(int consumerNum, String consumerName, String consumerAddr) {
		super();
		this.consumerNum = consumerNum;
		this.consumerName = consumerName;
		this.consumerAddr = consumerAddr;
	}

	public int getConsumerNum() {
		return consumerNum;
	}

	public void setConsumerNum(int consumerNum) {
		this.consumerNum = consumerNum;
	}

	public String getConsumerName() {
		return consumerName;
	}

	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}

	public String getConsumerAddr() {
		return consumerAddr;
	}

	public void setConsumerAddr(String consumerAddr) {
		this.consumerAddr = consumerAddr;
	}

	@Override
	public String toString() {
		return "Consumers [consumerNum=" + consumerNum + ", consumerName="
				+ consumerName + ", consumerAddr=" + consumerAddr + "]";
	}

}
