package com.cg.appl.servlet;

import java.io.IOException;  



import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.dto.BillDetails;
import com.cg.appl.exception.BillException;
import com.cg.appl.service.BillService;
import com.cg.appl.service.BillServiceImpl;


@WebServlet("*.do")
public class BillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//ServletContext config;
	BillService service;
	public void init(ServletConfig config) throws ServletException {
		service= new BillServiceImpl();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String nextJsp=null;
		String message=null;
		String path=request.getServletPath();
		System.out.println(path);
		if(path.equals("/main.do")){
			String user=request.getParameter("user");
			String password=request.getParameter("password");
			//config.setAttribute("user",user);
			
			boolean isAuthenticated=false;
			try {
				isAuthenticated = service.isUserAuthenticated(user, password);
			} catch (BillException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(isAuthenticated){
				//System.out.println("yes");
				nextJsp="/calculate.jsp";  //this file when is on server is in project
				
				
			}else{
				//System.out.println("no");
				message ="Wrong Credentials. Enter again.";
				request.setAttribute("errormsg", message);    //fr sending data through dispatcher
				nextJsp="/error.jsp";  //this file when is on server is in project
				
			}
			
			RequestDispatcher res=request.getRequestDispatcher(nextJsp);
			res.forward(request, response);
		}  //end of login page
		if(path.equals("/cal.do")){
			//System.out.println("calculation....");
			String conNum= request.getParameter("cno");

			String lRead= request.getParameter("lReading");

			String cRead= request.getParameter("cReading");

			int consNum= Integer.parseInt(conNum);

			int lsRead=Integer.parseInt(lRead);

			int crRead=Integer.parseInt(cRead);

			if(crRead<lsRead){

			System.out.println("Currnet reading cannot be less than last reading.");

			request.setAttribute("msg", "Currnet reading cannot be less than last reading.");

			RequestDispatcher disp= request.getRequestDispatcher("calculate.jsp");

			disp.forward(request, response);

			}else{

			int unitCon;

			float netAmt;

			int fix=100;

			unitCon= crRead-lsRead;

			netAmt= (float) ((unitCon*1.15)+fix);

			java.util.Date d= new java.util.Date();

			long current= d.getTime();

			Date dt= new Date(current);

			BillDetails billDet= new BillDetails();

			billDet.setConsumerNum(consNum);

			billDet.setCurntReading(crRead);

			billDet.setUnitConsumed(unitCon);

			billDet.setNetAmnt(netAmt);

			billDet.setBillDate(dt);

			try {

			int billId= service.addBillDetail(consNum, billDet);

			System.out.println("Bill ID: "+billId);

			request.setAttribute("BillData", billDet);

			RequestDispatcher disp= request.getRequestDispatcher("billSuccess.jsp");

			disp.forward(request, response);

			} catch (BillException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();
			response.sendRedirect("invalid.jsp");

			}

			}

			}


	}
		
	}

