package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns= "/calcInterest",initParams={@WebInitParam(name="x",value="20")})   //this sevlet config in servlet itself by uncomment
public class CalcInterest extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private float rateInterest;
	
	public void init() throws ServletException {
		
		ServletContext ctx=super.getServletContext();
		String rateInterestStr =ctx.getInitParameter("rateInterest");
		rateInterest=Float.parseFloat(rateInterestStr);
		System.out.println("From init():" +rateInterest);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext ctx=super.getServletContext();
		String rateInterestStr =ctx.getInitParameter("rateInterest");
		rateInterest=Float.parseFloat(rateInterestStr);
		System.out.println("From service():"+rateInterest);
		
		System.out.println(ctx.getContextPath());
		System.out.println(ctx.getMajorVersion());
		System.out.println(ctx.getMinorVersion());
		System.out.println(ctx.getServerInfo());
		System.out.println(ctx.getServletContextName());
		

		ServletConfig cfg=super.getServletConfig();            
		String xstr=cfg.getInitParameter("x");
/*int x=Integer.parseInt(xstr);*/                 //this line we make comment bcz config value for another is not shown by calcinterest servlet,so to show it null
		System.out.println(xstr);                //and put xstr instead of x
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
