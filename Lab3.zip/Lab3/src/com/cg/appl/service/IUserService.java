package com.cg.appl.service;

import java.util.List;

import com.cg.appl.dto.User;
import com.cg.appl.exception.UserException;


public interface IUserService {
	public boolean addUser(User user) throws UserException;
	public List<User> showAll();
}
