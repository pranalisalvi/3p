package com.cg.appl.service;

import java.util.List; 

import com.cg.appl.dao.IUserDao;
import com.cg.appl.dao.UserDaoImpl;
import com.cg.appl.dto.User;
import com.cg.appl.exception.UserException;

public class UserServiceImpl implements IUserService {
IUserDao userDao;

	public UserServiceImpl() {
		userDao=new UserDaoImpl();
	}
	@Override
	public boolean addUser(User user) throws UserException {
		return userDao.addUser(user);
	}

	@Override
	public List<User> showAll() {
		
		return null;
	}

}
