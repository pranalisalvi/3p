package com.cg.appl.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.dto.User;
import com.cg.appl.exception.UserException;
import com.cg.appl.service.IUserService;
import com.cg.appl.service.UserServiceImpl;

@WebServlet("*.do")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IUserService userService;
	
	public void init(ServletConfig config) throws ServletException {
		userService=new UserServiceImpl();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException{
		        User user=new User();
				String path= request.getServletPath();
				//System.out.println(path);
				if(path.equals("/userController.do")){             //whenever path is this go to addUser.jsp
					RequestDispatcher res=request.getRequestDispatcher("addUser.jsp");
					res.forward(request, response);
				}
				
				if(path.equals("/useradd.do")){
					String fname=request.getParameter("firstname");
					String lname=request.getParameter("lastname");
					String password=request.getParameter("password");
					String gender=request.getParameter("gender");
					String[] skills=request.getParameterValues("skill");
					String city=request.getParameter("city");
					
					String skillSet="";
					for(int i=0;i<skills.length;i++){
						skillSet=skillSet.concat(skills[i]);
					}
					
					char gen;
					if(gender.equals("Male")){
						gen='M';
					}else{
						gen='F';
					}
					user.setFirstName(fname);
					user.setLastName(lname);
					user.setPassword(password);
					user.setGender(gen);
					user.setSkillSet(skillSet);
					user.setCity(city);
					
					try {
						boolean val=userService.addUser(user);
						
						if(val==true){
						RequestDispatcher res=request.getRequestDispatcher("success.jsp");
						res.forward(request, response);
						}else{
							RequestDispatcher res=request.getRequestDispatcher("failure.jsp");
							res.forward(request, response);
						}
					} catch (UserException e) {
						e.printStackTrace();
						
					}
				}
	}

}
