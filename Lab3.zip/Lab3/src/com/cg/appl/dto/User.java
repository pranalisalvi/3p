package com.cg.appl.dto;



public class User {
	private String firstName;
	private String lastName;
	private String password;
	private char gender;
	private String skillSet;
	private String city;
	
	public User() {
		super();
	}

	public User(String firstName, String lastName, String password,
			char gender, String skillSet, String city) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.gender = gender;
		this.skillSet = skillSet;
		this.city = city;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "User [firstName=" + firstName + ", lastName=" + lastName
				+ ", password=" + password + ", gender=" + gender
				+ ", skillSet=" + skillSet + ", city=" + city + "]";
	}

	
	
}
