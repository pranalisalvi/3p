package com.cg.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.cg.appl.dto.User;
import com.cg.appl.exception.UserException;
import com.cg.appl.util.DbUtil;

public class UserDaoImpl implements IUserDao {

	@Override
	public boolean addUser(User user) throws UserException {
		Connection conn=null;
		PreparedStatement pstm=null;
		String query="INSERT INTO USERMANAGEMENT VALUES(?,?,?,?,?,?)";
		
		
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			
			pstm.setString(1,user.getFirstName());
			pstm.setString(2,user.getLastName());
			pstm.setString(3, user.getPassword());
			pstm.setString(4,String.valueOf(user.getGender()) );
			pstm.setString(5,user.getSkillSet());
			pstm.setString(6,user.getCity());
			
			int status=pstm.executeUpdate();
			if(status==1){
				System.out.println("data added");
				return true;
			}else{
				System.out.println("data not added");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
			throw new UserException("Problem in insert");
		}finally{
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}


	

}
