package com.cg.appl.dao;

import java.util.List;

import com.cg.appl.dto.User;
import com.cg.appl.exception.UserException;

public interface IUserDao {
	public boolean addUser(User user) throws UserException;
	
}
