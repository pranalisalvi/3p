CREATE TABLE USERMANAGEMENT(

user_fname varchar2(20),
user_lname varchar2(20),
user_pass varchar2(10));


alter table USERMANAGEMENT
ADD (user_gen char(5));

alter table USERMANAGEMENT
ADD user_skills varchar2(10);

alter table USERMANAGEMENT
ADD user_city varchar2(10);

select * from USERMANAGEMENT;