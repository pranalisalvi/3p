package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.exceptions.UserException;
import com.cg.appl.services.UserMasterServices;
import com.cg.appl.services.UserMasterServicesImpl;


@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterServices services;
	
	public void init() throws ServletException {
		try {
			services =new UserMasterServicesImpl();
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		String userName= request.getParameter("userNm");
		String password=request.getParameter("password");
		RequestDispatcher dispatch=null;
		String nextJsp=null;    //to avoid redundancy of dispatching code
		String message=null;    //to show msg on login page,error page
		try {
			boolean isAuthenticated=services.isUserAuthenticated(userName, password);
			if(isAuthenticated){
				//System.out.println("yes");
				nextJsp="/mainMenu.jsp";  //this file when is on server is in project
				
				
			}else{
				//System.out.println("no");
				message ="Wrong Credentials. Enter again.";
				request.setAttribute("errormsg", message);    //fr sending data through dispatcher
				nextJsp="/login.jsp";  
				
			}
		} catch (UserException e) {
			message ="Username does not exist.";
			request.setAttribute("errormsg", message); 
			nextJsp="/error.jsp";  
			
		}
		dispatch=request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, resp);
		//System.out.println(userName+" "+password);
	}



	public void destroy() {
		
	}

}
