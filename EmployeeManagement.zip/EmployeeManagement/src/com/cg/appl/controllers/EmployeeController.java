package com.cg.appl.controllers;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.dto.Employee;
import com.cg.appl.exception.EmployeeException;
import com.cg.appl.service.EmployeeServiceImpl;
import com.cg.appl.service.IEmployeeService;

@WebServlet("*.do")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
		IEmployeeService employeeService;
	
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		employeeService=new EmployeeServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	
	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String path= request.getServletPath();
		//System.out.println(path);
		if(path.equals("/employeeController.do")){             //whenever path is this go to addemployee.jsp
		RequestDispatcher res=request.getRequestDispatcher("addemployee.jsp");
		res.forward(request, response);
		}
		if(path.equals("/empadd.do")){
			Employee emp=new Employee();
			String name=request.getParameter("jname");
			String qualification=request.getParameter("jqual");
			String salary=request.getParameter("jsal");
			
			emp.setEmpName(name);
			emp.setEmpQualification(qualification);
			emp.setEmpSalary(Double.parseDouble(salary));
			
			
			try {
				int empId=employeeService.addEmployee(emp);
				request.setAttribute("id",empId);
				//System.out.println(empId);
				RequestDispatcher res=request.getRequestDispatcher("welcome.jsp");
				res.forward(request, response);
				
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(path.equals("/showall.do")){
			
			List<Employee> myList = null;
			try {
				myList = employeeService.showAll();
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println(myList);
			request.setAttribute("data",myList);           //this 3 lines for print data on browser
			RequestDispatcher req=request.getRequestDispatcher("showall.jsp");
			req.forward(request, response);
			
		}else if(path.equals("/update.do")){
			//System.out.println("update.....");
			String data=request.getQueryString();
			String empId=data.substring(3, 7);
			//System.out.println(empId);
			int id=Integer.parseInt(empId);
			Employee eData = null;
			try {
				eData = employeeService.getEmployeeDetail(id);
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println(eData);
			request.setAttribute("empData",eData);
			RequestDispatcher res=request.getRequestDispatcher("updateemployee.jsp");
			res.forward(request, response);
			
		}else if(path.equals("/updatedata.do")){
			//System.out.println("updatedata...");
			Employee emp1=new Employee();
			String id=request.getParameter("uid");
			String name=request.getParameter("uname");
			String qual=request.getParameter("uqual");
			String sal=request.getParameter("usal");
			
			emp1.setEmpid(Integer.parseInt(id));
			emp1.setEmpName(name);
			emp1.setEmpQualification(qual);
			emp1.setEmpSalary(Double.parseDouble(sal));
			 try {
				employeeService.updateEmployee(emp1);
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			 RequestDispatcher res=request.getRequestDispatcher("/showall.do");
				res.forward(request, response);
		}
	}

}
