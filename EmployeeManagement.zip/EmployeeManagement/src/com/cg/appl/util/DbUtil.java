package com.cg.appl.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.appl.exception.EmployeeException;

public class DbUtil {

	public static Connection obtainConnection() throws EmployeeException{
		Connection conn=null;
		InitialContext context;      //it is naming api searching for dirctory i.e.jndi name
		 try {
			context=new InitialContext();
			DataSource source=(DataSource) context.lookup("java:/OracleDS");
			conn=source.getConnection();
		} catch (NamingException e) {
			e.printStackTrace();
			throw new EmployeeException("Problem in connection");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		 return conn;
	}
		
}
