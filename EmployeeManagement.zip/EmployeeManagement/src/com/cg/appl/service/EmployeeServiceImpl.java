package com.cg.appl.service;

import java.util.List;

import com.cg.appl.dao.EmployeeDaoImpl;
import com.cg.appl.dao.IEmployeeDao;
import com.cg.appl.dto.Employee;
import com.cg.appl.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
IEmployeeDao empDao;
	public EmployeeServiceImpl() {
		empDao=new EmployeeDaoImpl();
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		
		return empDao.addEmployee(emp);
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		
		return empDao.showAll();
	}

	@Override
	public Employee getEmployeeDetail(int id) throws EmployeeException {
		
		return empDao.getEmployeeDetail(id);
	}

	@Override
	public boolean updateEmployee(Employee emp1) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.updateEmployee(emp1);
	}

}
