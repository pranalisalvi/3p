CREATE TABLE EMPLOYEEMANAGEMENT(
emp_id number(10) PRIMARY KEY,
emp_name varchar2(20),
emp_qual varchar2(20),
emp_sal number(10));

select * from EMPLOYEEMANAGEMENT;

create sequence empm_id_seq
START WITH 1002;

SELECT empm_id_seq.nextval from dual;

SELECT emp_id,emp_name,emp_qual,emp_sal FROM EMPLOYEEMANAGEMENT;

update EMPLOYEEMANAGEMENT set emp_name='Chirag',emp_qual='bcom',emp_sal=40000 Where emp_id=1004; 

