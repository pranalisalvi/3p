package com.cg.appl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/welcome")
public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private int visits=0;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Message on console"+request.getMethod());
		System.out.println("Message on console"+request.getServletPath());
		
		PrintWriter out=response.getWriter();
		out.write("Welcome----"+(++visits));//to print how many times visit
	}


	@Override
	public void destroy() {     //for undeployed servlet then this method run
		System.out.println("In destroy()");        //write stmt before
		super.destroy();
	}


	@Override
	public void init() throws ServletException {     //for deployed servlet this method run
		// TODO Auto-generated method stub
		super.init();
		System.out.println("In Init()");         //write stmt after 
	}

}
