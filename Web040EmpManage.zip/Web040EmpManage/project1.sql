select * from EMP;
