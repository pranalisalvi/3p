package com.cg.appl.exceptions;

public class EmpException extends Exception {

	public EmpException() {
		
	}

	public EmpException(String arg0) {
		super(arg0);
		
	}

	public EmpException(Throwable arg0) {
		super(arg0);
		
	}

	public EmpException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	public EmpException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		
	}

}
