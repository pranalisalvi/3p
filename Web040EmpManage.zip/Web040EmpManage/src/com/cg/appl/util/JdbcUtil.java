package com.cg.appl.util;


import java.sql.Connection;
import java.sql.SQLException;


import oracle.jdbc.pool.OracleDataSource;

public class JdbcUtil {
	//private Properties props;
	private OracleDataSource dataSource;     //SINCE get red line copy odbc.jar
	
	public JdbcUtil() {
		
		try {
			
			dataSource =new OracleDataSource();            //ek se jayda connection honge by taking uname pass
			dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G");
			dataSource.setUser("labg104trg8");
			dataSource.setPassword("labg104oracle");
			dataSource.setDriverType("oracle");
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() throws SQLException{        //import java.sql
		return dataSource.getConnection();
	}

	@Override
	protected void finalize() throws Throwable {
		dataSource.close();
		super.finalize();
	}

	
}
