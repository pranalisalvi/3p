package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;
import com.cg.appl.services.EmpServicesImpl;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmpServices services;
	private RequestDispatcher dispatch;
	private String nextJsp;

	public void init() throws ServletException {
		services = new EmpServicesImpl();
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String command = request.getServletPath();
		System.out.println("command:" + command);

		switch (command) {
		case "/acceptEmpNo.do": {
			nextJsp ="/acceptEmpNo.jsp";
			break;
		}

		case "/showEmpDetails.do": {
			try {
				String empNoStr= request.getParameter("empNo");
				//System.out.println(empNoStr);
				int empNo =Integer.parseInt(empNoStr);
				Employee emp= services.getEmpDetails(empNo);   
				request.setAttribute("emp", emp);
				
				nextJsp ="/showEmpDetails.jsp";
			} catch (NumberFormatException e) {
				request.setAttribute("errMsg", "wrong empNo input.");
				nextJsp ="/errors.jsp";
			}
			catch (EmpException e) {
				request.setAttribute("errMsg", "empNo not existing.");
				nextJsp ="/errors.jsp";
			}
			
			break;
		}
		}
		dispatch =request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	public void destroy() {
		services = null;
	}
}
