package com.cg.appl.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/getDate")
public class GetDate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DateFormat df=new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Date dateobj= new Date();
		System.out.println(df.format(dateobj));

		PrintWriter out=response.getWriter();
		out.write("date and time:"+df.format(dateobj));
		
			
	}

	
	@Override
	public void destroy() {     //for undeployed servlet then this method run
		System.out.println("In destroy()");        //write stmt before
		super.destroy();
	}


	@Override
	public void init() throws ServletException {     //for deployed servlet this method run
		// TODO Auto-generated method stub
		super.init();
		System.out.println("In Init()");         //write stmt after 
	}

}
