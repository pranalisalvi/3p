package com.cg.appl.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

public class JdbcUtil {
	//private Properties props;
	private OracleDataSource dataSource;     //SINCE get red line copy odbc.jar
	
	public JdbcUtil() {
		/* props=new Properties();
		 InputStream is=null;*/
		try {
			/*is = new FileInputStream("D:\\module 3p\\Web020LoginSimple\\src\\oracle.properties");  //open file
			props.load(is);                                 //load data
			
			dataSource =new OracleDataSource();            //ek se jayda connection honge by taking uname pass
			dataSource.setURL(props.getProperty("oracle.url"));
			dataSource.setUser(props.getProperty("oracle.uname"));
			dataSource.setPassword(props.getProperty("oracle.upass"));
			dataSource.setDriverType("oracle");
			*/
			dataSource =new OracleDataSource();            //ek se jayda connection honge by taking uname pass
			dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G");
			dataSource.setUser("labg104trg8");
			dataSource.setPassword("labg104oracle");
			dataSource.setDriverType("oracle");
		
		/*} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();*/
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}/*finally{
			try {
				is.close();              //close file 
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}         
		}*/
		
	}
	
	public Connection getConnection() throws SQLException{        //import java.sql
		return dataSource.getConnection();
	}

	@Override
	protected void finalize() throws Throwable {
		dataSource.close();
		super.finalize();
	}

	
}
