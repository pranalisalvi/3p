package com.cg.appl.servlets;

import java.sql.Connection;
import java.sql.SQLException;

import com.cg.appl.util.JdbcUtil;


public class TestUtil {

	public static void main(String[] args) {
		
		// TODO Auto-generated constructor stub
		JdbcUtil util=new JdbcUtil();
		try {
			Connection connect=util.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	

	}


