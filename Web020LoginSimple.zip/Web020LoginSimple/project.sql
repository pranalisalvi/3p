select * from Emp;

drop table UserMaster;

create table usermaster(
USERNAME Varchar2(15) primary key,
PASSWORD Varchar2(15),
USERFNAME Varchar2(40));

insert into usermaster(USERNAME,PASSWORD,USERFNAME) VALUES ('a','a','Pranali');
insert into usermaster(USERNAME,PASSWORD,USERFNAME) VALUES ('b','b','Piyu');

select * from usermaster;