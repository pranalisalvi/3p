package com.cg.appl.dao;

import java.util.ArrayList;

import com.cg.appl.entities.UserDetails;
import com.cg.appl.exception.UserException;

public interface UserRegisterDao {
	public boolean insertRecord(UserDetails user) throws UserException;
	public ArrayList<UserDetails> getUserList() throws UserException;
}
