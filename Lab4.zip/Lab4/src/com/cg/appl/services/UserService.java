package com.cg.appl.services;

import java.util.ArrayList;

import com.cg.appl.entities.UserDetails;
import com.cg.appl.exception.UserException;

public interface UserService {
	public boolean insertRecord(UserDetails user) throws UserException;
	public ArrayList<UserDetails> getUserList() throws UserException;
}
