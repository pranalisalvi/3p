package com.cg.appl.services;

import java.util.ArrayList;

import com.cg.appl.dao.UserRegisterDao;
import com.cg.appl.dao.UserRegisterDaoImpl;
import com.cg.appl.entities.UserDetails;
import com.cg.appl.exception.UserException;

public class UserServiceImpl implements UserService{

	private UserRegisterDao dao;

	public UserServiceImpl() throws UserException {

	dao= new UserRegisterDaoImpl();

	}

	@Override

	public boolean insertRecord(UserDetails user) throws UserException {

	return dao.insertRecord(user);

	}

	@Override

	public ArrayList<UserDetails> getUserList() throws UserException {

	// TODO Auto-generated method stub

	return dao.getUserList();

	}

}
