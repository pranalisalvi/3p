create table RegisteredUsers(
firstname varchar2(10),
lastname varchar2(20),
password varchar2(10),
gender char(2),
skillset varchar2(10),
city varchar(20)
);
INSERT INTO RegisteredUsers VALUES ('a','b','c','f','Java','Mumbai');
