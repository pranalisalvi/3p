package com.cg.appl.listeners;

import javax.servlet.ServletContextEvent; 
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;


@WebListener
public class CreateContextListener implements ServletContextListener {

    public void contextInitialized(ServletContextEvent arg0)  { 
        System.out.println("In contextInitialized() of CreateContextListener");
    }
	
    public void contextDestroyed(ServletContextEvent arg0)  { 
    	 System.out.println("In contextDestroyed() of CreateContextListener");
    }

   
}
