package com.cg.appl.listeners;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;


@WebListener
public class ManageCartListener implements HttpSessionListener {

   
    public void sessionCreated(HttpSessionEvent arg0)  { 
         System.out.println("In Session listener creation.");
    }

    public void sessionDestroyed(HttpSessionEvent arg0)  { 
    	  System.out.println("In Session listener destroyed.");
    
    }
	
}
