package com.cg.bill.Exception;

public class BillException extends Exception{

	public BillException() {
		super();
	}

	public BillException(String msg) {
		super(msg);
		
	}

	
}