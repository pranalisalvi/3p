package com.cg.bill.service;

import java.util.List;

import com.cg.bill.dto.BillDetails;

import com.cg.bill.dto.Consumers;

import com.cg.bill.dao.EBillDaoImpl;

import com.cg.bill.dao.IEBillDao;

import com.cg.bill.Exception.BillException;

public class EBillServiceImpl implements IEBillService {

IEBillDao billDao;

public EBillServiceImpl() {

billDao= new EBillDaoImpl();

}

@Override

public List<Consumers> showAll() throws BillException {

return billDao.showAll();

}

@Override

public Consumers searchCons(int id) throws BillException {

// TODO Auto-generated method stub

return billDao.searchCons(id);

}

@Override

public List<BillDetails> getBill(int conId) throws BillException {

return billDao.getBill(conId);

}

}