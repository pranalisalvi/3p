package com.cg.bill.dao;

import java.util.List;

import com.cg.bill.dto.BillDetails;

import com.cg.bill.dto.Consumers;

import com.cg.bill.Exception.BillException;

public interface IEBillDao {

public List<Consumers> showAll() throws BillException;

public Consumers searchCons(int id) throws BillException;

public List<BillDetails> getBill(int conId) throws BillException;

}