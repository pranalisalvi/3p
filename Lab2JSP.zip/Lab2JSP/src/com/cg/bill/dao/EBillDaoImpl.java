package com.cg.bill.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.util.ArrayList;

import java.util.List;

import com.cg.bill.dto.BillDetails;

import com.cg.bill.dto.Consumers;

import com.cg.bill.Exception.BillException;

import com.cg.bill.util.DbUtil;

public class EBillDaoImpl implements IEBillDao {

Connection conn= null;

public EBillDaoImpl() {

}

@Override

public List<Consumers> showAll() throws BillException {

List<Consumers> consList= new ArrayList<Consumers>();

PreparedStatement pstm1= null;

String showQry= "SELECT consumer_num, consumer_name, address FROM Consumers";

try {

conn= DbUtil.obtainConnection();

pstm1= conn.prepareStatement(showQry);

ResultSet res1= pstm1.executeQuery();

while(res1.next()){

Consumers cons= new Consumers();

cons.setConsumerNum(res1.getInt("consumer_num"));

cons.setConsumerName(res1.getString("consumer_name"));

cons.setConsumerAddr(res1.getString("address"));

consList.add(cons);

}

} catch (SQLException e) {

// TODO Auto-generated catch block

e.printStackTrace();

}

return consList;

}

@Override

public Consumers searchCons(int id) throws BillException {

PreparedStatement pstm2= null;

String searchQry= "SELECT consumer_num, consumer_name, address FROM Consumers WHERE consumer_num=?";

Consumers cons= new Consumers();

try {

conn= DbUtil.obtainConnection();

pstm2= conn.prepareStatement(searchQry);

pstm2.setInt(1, id);

ResultSet res2= pstm2.executeQuery();

while(res2.next()){

cons.setConsumerNum(res2.getInt("consumer_num"));

cons.setConsumerName(res2.getString("consumer_name"));

cons.setConsumerAddr(res2.getString("address"));

}

return cons;

} catch (SQLException e) {

// TODO Auto-generated catch block

e.printStackTrace();

}

return cons;

}

@Override

public List<BillDetails> getBill(int conId) throws BillException {

List<BillDetails> billdtls= new ArrayList<BillDetails>();

PreparedStatement pstm3= null;

String searchQry= "SELECT bill_num, consumer_num, cur_reading, unitConsumed, netAmount, bill_date FROM BillDetails WHERE consumer_num=?";

try {

conn= DbUtil.obtainConnection();

pstm3= conn.prepareStatement(searchQry);

pstm3.setInt(1, conId);

ResultSet res3= pstm3.executeQuery();

while(res3.next()){

BillDetails bills= new BillDetails();

bills.setBillNum(res3.getInt("bill_num"));

bills.setConsumerNum(res3.getInt("consumer_num"));

bills.setCurntReading(res3.getInt("cur_reading"));

bills.setUnitConsumed(res3.getInt("unitConsumed"));

bills.setNetAmnt(res3.getFloat("netAmount"));

bills.setBillDate(res3.getDate("bill_date"));

billdtls.add(bills);

}

} catch (SQLException e) {


e.printStackTrace();

}

return billdtls;

}

}
	