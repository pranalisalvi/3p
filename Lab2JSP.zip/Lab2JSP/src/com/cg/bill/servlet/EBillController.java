package com.cg.bill.servlet;





import java.io.IOException;
import java.util.List; 

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bill.dto.BillDetails;
import com.cg.bill.dto.Consumers;
import com.cg.bill.Exception.BillException;
import com.cg.bill.service.EBillServiceImpl;
import com.cg.bill.service.IEBillService;

@WebServlet("*.do")

public class EBillController extends HttpServlet {

private static final long serialVersionUID = 1L;

IEBillService billService;

private RequestDispatcher dispatch;

private String nextJsp;

public EBillController() {

super();

billService= new EBillServiceImpl();

}

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	processRequest(request, response);

}

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

processRequest(request, response);

}

private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

String path= request.getServletPath();

System.out.println(path);

if(path.equals("/showConsumerList.do")){

List<Consumers> myList= null;

try {

myList= billService.showAll();

request.setAttribute("data", myList);

nextJsp= "/showConsumerList.jsp";

} catch (BillException e) {

// TODO Auto-generated catch block

request.setAttribute("errMsg", "Error while retrieving details");

nextJsp="/errors.jsp";

e.printStackTrace();

}

}

else if(path.equals("/searchConsumer.do")){

nextJsp= "/searchConsumer.jsp";

}

else if(path.equals("/search.do")){

String consIdStr= request.getParameter("cId");

int consId= Integer.parseInt(consIdStr);

try {

Consumers consumer= billService.searchCons(consId);

request.setAttribute("dataCons", consumer);

nextJsp= "/showConsumer.jsp";

} catch (BillException e) {

// TODO Auto-generated catch block

request.setAttribute("errMsg", "Error while searching consumer");

nextJsp="/errors.jsp";

e.printStackTrace();

}

//nextJsp= "/searchConsumer.jsp";

}

else if(path.equals("/showBill.do")){

System.out.println("Called showBill for 1");

List<BillDetails> billData= null;

String data= request.getQueryString();
System.out.println(data);
String u_id= data.substring(3,9);

int uid= Integer.parseInt(u_id);
System.out.println("show"+uid);
try {

billData= billService.getBill(uid);

request.setAttribute("billData", billData);

nextJsp= "/showBills.jsp";

} catch (BillException e) {

// TODO Auto-generated catch block

request.setAttribute("errMsg", "Error while getting bill details");

nextJsp="/errors.jsp";

e.printStackTrace();

}

}

dispatch= request.getRequestDispatcher(nextJsp);

dispatch.forward(request, response);

}

}